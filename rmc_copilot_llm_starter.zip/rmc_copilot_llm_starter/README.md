# RMC Copilot LLM Starter

Frente local do RMC Copilot focada em LLM educacional, RAG local e futura integração com DuckDB/Parquet/CSV.

## Camadas

1. `src/rmc_mini_llm`: mini-LLM educacional em PyTorch, char-level.
2. `src/rmc_rag`: assistente útil com Ollama + RAG local simples.
3. `data/sample`: exemplo de dados CSV para preparar integração futura com DuckDB/Parquet.

## Setup Windows PowerShell

```powershell
cd C:\RMC\rmc-copilot-llm
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements-rag.txt
pip install -r requirements-edu.txt
```

## Mini-LLM educacional

```powershell
python .\src\rmc_mini_llm\train_char_lm.py --data .\data\train\rmc_tiny_corpus.txt --epochs 40
python .\src\rmc_mini_llm\generate.py --checkpoint .\models\mini_char_lm.pt --prompt "Cluster BV_PRD_09_SQL apresenta"
```

## Assistente RAG com Ollama

Instale Ollama e baixe um modelo pequeno:

```powershell
ollama pull gemma3:1b
ollama pull paraphrase-multilingual
```

Construa o índice:

```powershell
python .\src\rmc_rag\build_index.py --docs .\docs --csv .\data\sample\rmc_vm_snapshot.csv --out .\rag_index
```

Pergunte:

```powershell
python .\src\rmc_rag\chat_rag.py --index .\rag_index --model gemma3:1b --question "Quais VMs estão em risco e qual ação devo tomar?"
```

