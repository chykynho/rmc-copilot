# Regras operacionais do RMC Copilot

## Prioridade

- P0: saturação atual ou risco crítico imediato. Ação: tratar imediatamente.
- P1: risco em até 30 dias. Ação: analisar curto prazo e reservar capacidade.
- P2: risco em 60 dias ou recurso em atenção. Ação: planejar expansão ou rightsizing.
- P3: risco em 90 dias ou tendência moderada. Ação: monitorar no radar mensal.
- P4: sem risco relevante. Ação: manter monitoramento.

## CPU

- CPU acima de 85% recorrente indica atenção.
- CPU acima de 90% recorrente indica risco.
- CPU muito baixa com muitas vCPUs pode indicar superdimensionamento.

## Memória

- Memória acima de 85% recorrente indica atenção.
- Memória acima de 90% recorrente indica risco.
- Memória muito baixa com muita RAM alocada pode indicar oportunidade de rightsizing.

## Disco e datastore

- Disco ou partição acima de 85% indica atenção.
- Disco ou partição acima de 90% indica risco crítico.
- Datastore deve ser analisado por capacidade total, usado, livre e tendência de crescimento.

## Forecast

- Forecast 30 dias: risco de curto prazo.
- Forecast 60 dias: risco planejável.
- Forecast 90 dias: tendência para radar mensal.

## Recomendações

Toda recomendação deve explicar:
1. recurso afetado;
2. evidência numérica;
3. impacto operacional;
4. ação sugerida;
5. prioridade P0/P1/P2/P3/P4.
