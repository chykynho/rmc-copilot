ollama pull gemma3:1b
ollama pull paraphrase-multilingual
ollama list
