.\.venv\Scripts\Activate.ps1
python .\src\rmc_rag\build_index.py --docs .\docs --csv .\data\sample\rmc_vm_snapshot.csv --out .\rag_index
