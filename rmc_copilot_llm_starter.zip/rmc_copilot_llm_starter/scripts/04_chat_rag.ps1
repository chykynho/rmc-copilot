.\.venv\Scripts\Activate.ps1
python .\src\rmc_rag\chat_rag.py --index .\rag_index --model gemma3:1b --question "Quais VMs estão em risco e qual ação devo tomar?"
