import argparse
import torch
import torch.nn as nn
from torch.nn import functional as F
from pathlib import Path

class TinyCharTransformer(nn.Module):
    def __init__(self, vocab_size, n_embd=96, n_head=4, n_layer=2, block_size=96, dropout=0.1):
        super().__init__()
        self.block_size = block_size
        self.token_embedding = nn.Embedding(vocab_size, n_embd)
        self.position_embedding = nn.Embedding(block_size, n_embd)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=n_embd, nhead=n_head, dim_feedforward=4*n_embd,
            dropout=dropout, batch_first=True, activation="gelu"
        )
        self.blocks = nn.TransformerEncoder(encoder_layer, num_layers=n_layer)
        self.ln = nn.LayerNorm(n_embd)
        self.head = nn.Linear(n_embd, vocab_size)

    def forward(self, idx):
        b, t = idx.shape
        idx = idx[:, -self.block_size:]
        t = idx.shape[1]
        pos = torch.arange(0, t, device=idx.device)
        x = self.token_embedding(idx) + self.position_embedding(pos)[None, :, :]
        mask = torch.triu(torch.ones(t, t, device=idx.device), diagonal=1).bool()
        x = self.blocks(x, mask=mask)
        x = self.ln(x)
        return self.head(x)

@torch.no_grad()
def generate(model, idx, max_new_tokens, temperature=0.8):
    for _ in range(max_new_tokens):
        logits = model(idx)
        logits = logits[:, -1, :] / temperature
        probs = F.softmax(logits, dim=-1)
        next_id = torch.multinomial(probs, num_samples=1)
        idx = torch.cat((idx, next_id), dim=1)
    return idx

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--prompt", default="RMC Copilot")
    parser.add_argument("--tokens", type=int, default=300)
    args = parser.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    ckpt = torch.load(args.checkpoint, map_location=device)
    chars = ckpt["chars"]
    stoi = {ch: i for i, ch in enumerate(chars)}
    itos = {i: ch for i, ch in enumerate(chars)}
    model = TinyCharTransformer(len(chars), block_size=ckpt["block_size"]).to(device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()

    prompt = ''.join([c if c in stoi else ' ' for c in args.prompt])
    idx = torch.tensor([[stoi[c] for c in prompt]], dtype=torch.long, device=device)
    out = generate(model, idx, args.tokens)[0].tolist()
    print(''.join(itos[i] for i in out))

if __name__ == "__main__":
    main()
