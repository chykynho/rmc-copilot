import argparse
from pathlib import Path
import torch
import torch.nn as nn
from torch.nn import functional as F

class TinyCharTransformer(nn.Module):
    def __init__(self, vocab_size, n_embd=96, n_head=4, n_layer=2, block_size=96, dropout=0.1):
        super().__init__()
        self.block_size = block_size
        self.token_embedding = nn.Embedding(vocab_size, n_embd)
        self.position_embedding = nn.Embedding(block_size, n_embd)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=n_embd,
            nhead=n_head,
            dim_feedforward=4 * n_embd,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.blocks = nn.TransformerEncoder(encoder_layer, num_layers=n_layer)
        self.ln = nn.LayerNorm(n_embd)
        self.head = nn.Linear(n_embd, vocab_size)

    def forward(self, idx, targets=None):
        b, t = idx.shape
        pos = torch.arange(0, t, device=idx.device)
        x = self.token_embedding(idx) + self.position_embedding(pos)[None, :, :]
        # máscara causal: cada posição só olha para o passado
        mask = torch.triu(torch.ones(t, t, device=idx.device), diagonal=1).bool()
        x = self.blocks(x, mask=mask)
        x = self.ln(x)
        logits = self.head(x)
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))
        return logits, loss

@torch.no_grad()
def estimate_loss(model, data, block_size, batch_size, device):
    model.eval()
    losses = []
    for _ in range(10):
        x, y = get_batch(data, block_size, batch_size, device)
        _, loss = model(x, y)
        losses.append(loss.item())
    model.train()
    return sum(losses) / len(losses)

def get_batch(data, block_size, batch_size, device):
    max_start = len(data) - block_size - 1
    ix = torch.randint(max_start, (batch_size,))
    x = torch.stack([data[i:i+block_size] for i in ix]).to(device)
    y = torch.stack([data[i+1:i+block_size+1] for i in ix]).to(device)
    return x, y

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--block-size", type=int, default=96)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--out", default="models/mini_char_lm.pt")
    args = parser.parse_args()

    text = Path(args.data).read_text(encoding="utf-8")
    chars = sorted(list(set(text)))
    stoi = {ch: i for i, ch in enumerate(chars)}
    itos = {i: ch for ch, i in stoi.items()}
    encoded = torch.tensor([stoi[c] for c in text], dtype=torch.long)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"device={device} vocab={len(chars)} chars={len(encoded)}")

    model = TinyCharTransformer(vocab_size=len(chars), block_size=args.block_size).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr)

    for step in range(args.epochs * 100):
        xb, yb = get_batch(encoded, args.block_size, args.batch_size, device)
        _, loss = model(xb, yb)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        if step % 100 == 0:
            print(f"step={step} loss={loss.item():.4f}")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model_state": model.state_dict(),
        "chars": chars,
        "block_size": args.block_size,
    }, out)
    print(f"salvo em {out}")

if __name__ == "__main__":
    main()
