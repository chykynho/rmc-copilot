import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sentence_transformers import SentenceTransformer

EMBED_MODEL = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

def chunk_text(text, size=900, overlap=120):
    text = text.replace("\r", "")
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + size, len(text))
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - overlap
        if start < 0:
            start = 0
        if end == len(text):
            break
    return chunks

def load_docs(docs_dir):
    records = []
    for path in Path(docs_dir).rglob("*"):
        if path.suffix.lower() not in [".txt", ".md", ".csv"]:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for i, chunk in enumerate(chunk_text(text)):
            records.append({"source": str(path), "chunk_id": i, "text": chunk})
    return records

def load_csv_as_docs(csv_path):
    if not csv_path:
        return []
    df = pd.read_csv(csv_path)
    records = []
    for i, row in df.iterrows():
        text = (
            f"Cluster: {row.get('cluster')} | Host: {row.get('host')} | VM: {row.get('vm')} | "
            f"CPU p95: {row.get('cpu_p95')}% | Memoria p95: {row.get('mem_p95')}% | "
            f"Disco usado: {row.get('disk_used_pct')}% | Datastore: {row.get('datastore')} | "
            f"Datastore usado: {row.get('datastore_used_pct')}% | "
            f"Forecast 30d: {row.get('forecast_30d')} | 60d: {row.get('forecast_60d')} | 90d: {row.get('forecast_90d')} | "
            f"Prioridade: {row.get('prioridade')}"
        )
        records.append({"source": str(csv_path), "chunk_id": int(i), "text": text})
    return records

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--docs", required=True)
    parser.add_argument("--csv", default=None)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    records = load_docs(args.docs) + load_csv_as_docs(args.csv)
    if not records:
        raise SystemExit("Nenhum documento encontrado para indexar.")

    model = SentenceTransformer(EMBED_MODEL)
    texts = [r["text"] for r in records]
    emb = model.encode(texts, normalize_embeddings=True, show_progress_bar=True)
    emb = np.asarray(emb, dtype="float32")

    np.savez_compressed(out / "embeddings.npz", embeddings=emb)
    with (out / "records.jsonl").open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"indexado: {len(records)} chunks em {out}")

if __name__ == "__main__":
    main()
