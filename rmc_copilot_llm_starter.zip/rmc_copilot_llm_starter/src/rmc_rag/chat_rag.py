import argparse
import json
from pathlib import Path
import requests
import numpy as np
from sentence_transformers import SentenceTransformer

EMBED_MODEL = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
OLLAMA_URL = "http://localhost:11434/api/chat"

SYSTEM_PROMPT = """
Você é o RMC Copilot, assistente local de Capacity Planning VMware.
Responda em português, com foco operacional.
Use SOMENTE o contexto fornecido.
Quando faltar dado, diga claramente: "Não encontrei evidência suficiente no contexto".
Sempre que possível, organize a resposta em:
- Diagnóstico
- Evidências
- Risco
- Prioridade
- Ação recomendada
""".strip()

def load_index(index_dir):
    index_dir = Path(index_dir)
    emb = np.load(index_dir / "embeddings.npz")["embeddings"]
    records = []
    with (index_dir / "records.jsonl").open("r", encoding="utf-8") as f:
        for line in f:
            records.append(json.loads(line))
    return emb, records

def retrieve(question, emb, records, k=5):
    model = SentenceTransformer(EMBED_MODEL)
    q = model.encode([question], normalize_embeddings=True)[0].astype("float32")
    scores = emb @ q
    idxs = np.argsort(-scores)[:k]
    return [(float(scores[i]), records[i]) for i in idxs]

def call_ollama(model_name, question, contexts):
    context_text = "\n\n".join(
        [f"[Fonte: {r['source']} | chunk {r['chunk_id']} | score {s:.3f}]\n{r['text']}" for s, r in contexts]
    )
    user_prompt = f"""
Pergunta do usuário:
{question}

Contexto recuperado:
{context_text}

Responda com base no contexto acima.
""".strip()

    payload = {
        "model": model_name,
        "stream": False,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
        "options": {"temperature": 0.2, "num_ctx": 4096}
    }
    resp = requests.post(OLLAMA_URL, json=payload, timeout=180)
    resp.raise_for_status()
    return resp.json()["message"]["content"]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", required=True)
    parser.add_argument("--model", default="gemma3:1b")
    parser.add_argument("--question", required=True)
    parser.add_argument("--k", type=int, default=5)
    args = parser.parse_args()

    emb, records = load_index(args.index)
    contexts = retrieve(args.question, emb, records, k=args.k)
    answer = call_ollama(args.model, args.question, contexts)

    print("\n=== RESPOSTA ===\n")
    print(answer)
    print("\n=== FONTES RECUPERADAS ===")
    for score, rec in contexts:
        print(f"score={score:.3f} source={rec['source']} chunk={rec['chunk_id']}")

if __name__ == "__main__":
    main()
